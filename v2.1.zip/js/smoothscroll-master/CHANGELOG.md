
# <= 0.4.4

* Support `scrollIntoView` on `document.body`
* Support scroll behaviors in shadow DOM

# <= 0.4.3

* ¯\_(ツ)_/¯
